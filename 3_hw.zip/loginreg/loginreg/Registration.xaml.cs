﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace loginreg
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        public Registration()
        {
            InitializeComponent();
        }

        private string USERinit { get; set; }
        private string MAILinit { get; set; }
        private string PASSinit { get; set; }
        private string CPASinit { get; set; }

        private void Reset()
        {
            NSP_txtbox.Text = "";
            email_txtbox.Text = "";
            pass_txtbox.Password = "";
            confpass_txtbox.Password = "";
        }

        private void reset_btn_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }

        void field_checking()
        {
            Application.Current.Dispatcher.Invoke(() => USERinit = NSP_txtbox.Text);
            Application.Current.Dispatcher.Invoke(() => MAILinit = email_txtbox.Text);
            Application.Current.Dispatcher.Invoke(() => PASSinit = pass_txtbox.Password);
            Application.Current.Dispatcher.Invoke(() => CPASinit = confpass_txtbox.Password);

            if (USERinit.Length == 0)
                MessageBox.Show("Enter name surname patronymic");

            if (MAILinit.Length == 0)
                MessageBox.Show("Enter email");
            else if(!Regex.IsMatch(MAILinit, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
                MessageBox.Show("Enter valid email");

            if(PASSinit.Length == 0)
                MessageBox.Show("Enter password");            

            if (CPASinit.Length == 0)
                MessageBox.Show("Enter confirmation password");
            else if(PASSinit != CPASinit)
                MessageBox.Show("Enter the equal password");           
        }

        async Task to_db()
        {
            await Task.Run(() => field_checking());

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-94PNF80;Initial Catalog=LoginReg;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            Task.Run(async () =>  await conn.OpenAsync());
            Task.Delay(3000).Wait();

            SqlCommand cmd = new SqlCommand("INSERT INTO Users(UserInit, UserMail, UserPass) VALUES('" + USERinit + "','" + MAILinit + "','" + PASSinit + "')", conn);

            cmd.CommandType = CommandType.Text;
            Task.Run(async()=> cmd.ExecuteNonQueryAsync());
            Task.Delay(3000).Wait();
            conn.Close();

            MessageBox.Show("You ve registered successfully");

            Reset();
        } 

        private async void submit_btn_Click(object sender, RoutedEventArgs e)
        {
            await to_db();
        }
    }
}
