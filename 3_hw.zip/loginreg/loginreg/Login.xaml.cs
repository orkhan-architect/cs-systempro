﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace loginreg
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            InitializeComponent();
        }

        private string LogMAILinit { get; set; }
        private string LogPASSinit { get; set; }

        void log_field_checking()
        {
            Application.Current.Dispatcher.Invoke(() => LogMAILinit = log_email_txtbox.Text);
            Application.Current.Dispatcher.Invoke(() => LogPASSinit = log_pass_txtbox.Password);

            if (LogMAILinit.Length == 0)
                MessageBox.Show("Enter email");
            else if (!Regex.IsMatch(LogMAILinit, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
                MessageBox.Show("Enter valid email");

            if (LogPASSinit.Length == 0)
                MessageBox.Show("Enter password");
        }

        async Task to_log_db()
        {
            await Task.Run(() => log_field_checking());

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-94PNF80;Initial Catalog=LoginReg;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            Task.Run(async () => await conn.OpenAsync());
            Task.Delay(3000).Wait();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE UserMail='" + LogMAILinit + "'  and UserPass='" + LogPASSinit + "'", conn);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = cmd;

            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);

            if (dataSet.Tables[0].Rows.Count > 0)
            {
                string userNSP = dataSet.Tables[0].Rows[0]["UserInit"].ToString();

                MessageBox.Show("Welcome Mr/Mrs " + userNSP);
            }
            else
            {
                MessageBox.Show("You ve entered invalid data. Try again");
            }

            Task.Delay(3000).Wait();
            conn.Close();
        }

        private async void log_submit_btn_Click(object sender, RoutedEventArgs e)
        {
            await to_log_db();

            log_email_txtbox.Text = "";
            log_pass_txtbox.Password = "";
        }
    }
}
