﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace textsearcher
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();           
        }

        public string GotText { get; set; }
        public bool? Check_sentence { get; set; }
        public bool? Check_symbol { get; set; }
        public bool? Check_word { get; set; }
        public bool? Check_question { get; set; }
        public bool? Check_interjection { get; set; }
        public bool? Check_show_res { get; set; }
        public bool? Check_save_res { get; set; }
        public object Last_result { get; set; }

        private int sent_count=0;
        private int symb_count=0;
        private int word_count=0;
        private int ques_count=0;
        private int inte_count=0;

        private CancellationTokenSource cancel1;       

        private byte[] asci_arr;

        private async Task My_filter()
        {
            await Task.Run(() => {
                Application.Current.Dispatcher.Invoke(() => GotText = huge_txtbox.Text);
                asci_arr = Encoding.ASCII.GetBytes(GotText);

                Application.Current.Dispatcher.Invoke(() => Check_sentence = sentence_chebox.IsChecked);
                Application.Current.Dispatcher.Invoke(() => Check_symbol = symbol_chebox.IsChecked);
                Application.Current.Dispatcher.Invoke(() => Check_word = word_chebox.IsChecked);
                Application.Current.Dispatcher.Invoke(() => Check_question = question_chebox.IsChecked);
                Application.Current.Dispatcher.Invoke(() => Check_interjection = interjection_chebox.IsChecked);

                Application.Current.Dispatcher.Invoke(() => Check_show_res = Show_text_rbtn.IsChecked);
                Application.Current.Dispatcher.Invoke(() => Check_save_res = Saveto_file_rbtn.IsChecked);
            });
        }

        private async Task Find_words_count()
        {
            Task.Delay(2000).Wait();
            await Task.Run(() =>
            {
                char[] delimiters = new char[] { ' ', '\r', '\n', '.', ',', '!', '?' };
                word_count = GotText.Split(delimiters, StringSplitOptions.RemoveEmptyEntries).Length;
            });
        }

        private async Task Find_symbols_count()
        {
            Task.Delay(2000).Wait();
            await Task.Run(() =>
            {
                for (int i = 0; i < asci_arr.Length; i++)
                    if (asci_arr[i] < 48 || (asci_arr[i] > 57 && asci_arr[i] < 65) || (asci_arr[i] > 90 && asci_arr[i] < 97) || asci_arr[i] > 122)
                        symb_count++;
            });
        }

        private async Task Find_sentences_count()
        {
            Task.Delay(2000).Wait();
            await Task.Run(() =>
            {
                for (int i = 0; i < asci_arr.Length; i++)
                    if (asci_arr[i] == 33 || asci_arr[i] == 46 || asci_arr[i] == 63)
                        sent_count++;
            });
        }

        private async Task Find_interjections_count()
        {
            Task.Delay(2000).Wait();
            await Task.Run(() =>
            {
                for (int i = 0; i < asci_arr.Length; i++)
                    if (asci_arr[i] == 33)
                        inte_count++;
            });
        }

        private async Task Find_questions_count()
        {
            Task.Delay(2000).Wait();
            await Task.Run(() =>
            {
                for (int i = 0; i < asci_arr.Length; i++)
                    if (asci_arr[i] == 63)
                        ques_count++;
            });
        }

        private async Task App_runner()
        {
            Task.Delay(6000).Wait();
            await My_filter();

            string res_text = "";

            for (int i = 0; i < 5; i++)
            {
                if (cancel1.IsCancellationRequested)
                {                    
                    break;
                }
                else
                {
                    if (Check_sentence == true)
                    {
                        await Find_sentences_count();

                        res_text += ("Sentences count is " + sent_count.ToString() + '\n');
                        Check_sentence = false;
                    }
                    else if (Check_symbol == true)
                    {
                        await Find_symbols_count();

                        res_text += ("Symbols count is " + symb_count.ToString() + '\n');
                        Check_symbol = false;
                    }
                    else if (Check_word == true)
                    {
                        await Find_words_count();

                        res_text += ("Words count is " + word_count.ToString() + '\n');
                        Check_word = false;
                    }
                    else if (Check_question == true)
                    {
                        await Find_questions_count();

                        res_text += ("Questions count is " + ques_count.ToString() + '\n');
                        Check_question = false;
                    }
                    else if (Check_interjection == true)
                    {
                        await Find_interjections_count();

                        res_text += ("Interjections count is " + inte_count.ToString() + '\n');
                        Check_interjection = false;
                    }
                }
            }

            if (Check_show_res == true)
            {
                Application.Current.Dispatcher.Invoke(() => Result_text.Content = res_text);
                
            }
            else if (Check_save_res == true)
            {
                try
                {
                    using (FileStream fs = new FileStream("informations.txt", FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        byte[] wr_bytes = Encoding.Default.GetBytes(res_text);
                        fs.Write(wr_bytes, 0, wr_bytes.Length);
                        MessageBox.Show("File was created successfully.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            sent_count = 0;
            symb_count = 0;
            word_count = 0;
            ques_count = 0;
            inte_count = 0;
        }

        private async void Start_btn_Click(object sender, RoutedEventArgs e)
        {
            cancel1 = new CancellationTokenSource();
            CancellationToken ct1 = cancel1.Token;

            try
            {
                await Task.Factory.StartNew(() => App_runner(), ct1);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void Pause_btn_Click(object sender, RoutedEventArgs e)
        {            
            await Task.Run(() => cancel1.Cancel(true));
            MessageBox.Show("Your start is canceled");
        }
    }
}
