﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace filemoving
{
    public partial class Form1 : Form
    {
        private Thread thread;

        private void CopyAll(DirectoryInfo oOriginal, DirectoryInfo oFinal)
        {
            foreach (DirectoryInfo oFolder in oOriginal.GetDirectories())
                this.CopyAll(oFolder, oFinal.CreateSubdirectory(oFolder.Name));            

            foreach (FileInfo oFile in oOriginal.GetFiles())
            {
                oFile.MoveTo(oFinal.FullName + @"\" + oFile.Name);                
                ++progressBar1.Value;
                Thread.Sleep(5000);
            }
        }

        public Form1()
        {
            InitializeComponent();
            thread = new Thread(() => this.CopyAll(new DirectoryInfo(textBox1.Text), new DirectoryInfo(textBox2.Text)));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textBox1.Text = folderBrowserDialog1.SelectedPath;

            progressBar1.Minimum = 0;
            progressBar1.Maximum = System.IO.Directory.GetFiles(textBox1.Text, "*.*", SearchOption.AllDirectories).Count();
            progressBar1.Step = 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog2.ShowDialog();
            textBox2.Text = folderBrowserDialog2.SelectedPath;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            thread.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            thread.Abort();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            thread.Suspend();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            thread.Resume();
        }
    }
}
