﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace threadpriority
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();            
        }

        static void num_generator(int start_num, int end_num, ListBox char_arr)
        {            
            Random rd = new Random();
            int rand_num = rd.Next(start_num, end_num);
            Thread.Sleep(3000);
            Application.Current.Dispatcher.Invoke(() => char_arr.Items.Add((char)rand_num));                   
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            Thread thread_1 = new Thread(() => num_generator(48, 57, Char_Resource));
            Thread thread_2 = new Thread(() => num_generator(65, 90, Char_Resource));
            Thread thread_3 = new Thread(() => num_generator(33, 47, Char_Resource));            

            if (N_High_RB.IsChecked == true)
                thread_1.Priority = ThreadPriority.Highest;
            else if (N_Normal_RB.IsChecked == true)
                thread_1.Priority = ThreadPriority.Normal;
            else
                thread_1.Priority = ThreadPriority.Lowest;            

            if (L_High_RB.IsChecked == true)
                thread_2.Priority = ThreadPriority.Highest;
            else if (L_Normal_RB.IsChecked == true)
                thread_2.Priority = ThreadPriority.Normal;
            else
                thread_2.Priority = ThreadPriority.Lowest;
            
            if (S_High_RB.IsChecked == true)
                thread_3.Priority = ThreadPriority.Highest;
            else if (S_Normal_RB.IsChecked == true)
                thread_3.Priority = ThreadPriority.Normal;
            else
                thread_3.Priority = ThreadPriority.Lowest;

            thread_1.Start();
            thread_2.Start();
            thread_3.Start();
        }
    }
}
