﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fibonatchi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();            
        }

        Thread thread_1;
        Thread thread_2;

        static void num_range(string first_num, string last_num, ListBox range)
        {            
            if (String.IsNullOrEmpty(first_num) && String.IsNullOrEmpty(last_num))
            {
                MessageBox.Show("fill the fields");
            }                    
            else if (String.IsNullOrEmpty(first_num))
            {
                for (int i = 2; i <= Convert.ToInt32(last_num); i++)
                {
                    range.Items.Add(i);
                    Thread.Sleep(3000);
                }                        
            }                    
            else if (String.IsNullOrEmpty(last_num))
            {
                for (int i = Convert.ToInt32(first_num); true; i++)
                {
                    range.Items.Add(i);
                    Thread.Sleep(3000);
                }                        
            }                    
            else
            {
                for (int i = Convert.ToInt32(first_num); i <= Convert.ToInt32(last_num); i++)
                {
                    range.Items.Add(i);
                    Thread.Sleep(3000);
                }                        
            }           
        }

        static void fibo_range(ListBox FIBOrange)
        {
            FIBOrange.Items.Add(0);
            FIBOrange.Items.Add(1);

            int num_1 = 0;
            int num_2 = 1;
            int tmp = 0;

            for (int i = 0; true; i++)
            {
                tmp = num_2 + num_1;
                FIBOrange.Items.Add(tmp);
                num_1 = num_2;
                num_2 = tmp;

                if (tmp == 4181)
                    break;

                Thread.Sleep(3000);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            thread_1 = new Thread(()=>num_range(textBox1.Text, textBox2.Text, listBox1), 1);
            thread_1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            thread_1.Abort();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            thread_1.Suspend();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            thread_1.Resume();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            thread_2 = new Thread(() => fibo_range(listBox2), 1);
            thread_2.Start();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            thread_2.Abort();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            thread_2.Suspend();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            thread_2.Resume();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();

            Thread.Sleep(2000);

            thread_1 = new Thread(() => num_range(textBox1.Text, textBox2.Text, listBox1), 1);
            thread_1.Start();

            thread_2 = new Thread(() => fibo_range(listBox2), 1);
            thread_2.Start();
        }
    }
}
