﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace lab1
{
    internal class Program
    {
        static object locker = new object();

        static void NumRange()
        {
            for (int i = 0; i < 51; i++)
            {
                Console.WriteLine(i);
            }
        }

        static void ParamNumRange(int start_num, int end_num)
        {
            lock (locker)
            {
                for (int i = start_num; i < end_num; i++)                
                    Console.WriteLine(i);                
            }            
        }

        static int[] rand_array(int array_size)
        {
            int[] rand_array = new int[array_size];
            Random rd = new Random();
            for (int i = 0; i < rand_array.Length; i++)
            {
                int rand_num = rd.Next(100, 200);
                rand_array[i] = rand_num;
            }
            return rand_array;
        }

        static void get_min_val(int[] given_array)
        {
            Console.WriteLine("Your min value is " + given_array.Min());

            int arr_length = given_array.Length;            
            for (int i = 0; i < arr_length; i++)
                Console.WriteLine(given_array[i]);
        }

        static void get_max_val(int[] given_array)
        {            
            Console.WriteLine("Your max value is " + given_array.Max());

            int arr_length = given_array.Length;
            for (int i = 0; i < arr_length; i++)
                Console.WriteLine(given_array[i]);
        }

        static void get_ave_val(int[] given_array)
        {
            Console.WriteLine("Your average value is " + given_array.Average());

            int arr_length = given_array.Length;
            for (int i = 0; i < arr_length; i++)
                Console.WriteLine(given_array[i]);
        }

        static void get_subtraction(int[] given_array)
        {
            StringBuilder full_list = new StringBuilder();
            int arr_length = given_array.Length;

            for (int i = 0; i < arr_length-1; i++)
            {
                int result = given_array[i] - given_array[i+1];
                Console.WriteLine($"{given_array[i]} - {given_array[i + 1]} = {result}");

                full_list.AppendLine($"{given_array[i]} - {given_array[i + 1]} = {result}");
            }

            Console.WriteLine("---------------");
            
            for (int i = 0; i < arr_length; i++)
            {
                Console.WriteLine(given_array[i]);
                full_list.AppendLine(given_array[i].ToString());
            }

            try
            {
                using (FileStream fs = new FileStream("subtres.txt", FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] wr_bytes = Encoding.Default.GetBytes(full_list.ToString());
                    fs.Write(wr_bytes, 0, wr_bytes.Length);
                    Console.WriteLine("File was created successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("This file already exists");
            }
        }

        static void Main(string[] args)
        {
            //Thread thread = new Thread(NumRange);
            //thread.Start();

            //Thread thread = new Thread(() => ParamNumRange(5, 15));
            //thread.Start();

            //int thread_count;
            //Console.Write("Choose thread count: ");
            //thread_count = Convert.ToInt32(Console.ReadLine());

            //for (int i = 0; i < thread_count; i++)
            //{
            //    Thread thread = new Thread(() => ParamNumRange(5, 11));
            //    thread.Start();
            //}

            int[] myArray = rand_array(4);

            //Thread thread = new Thread(() => get_min_val(myArray));
            //thread.Start();

            //Thread thread = new Thread(() => get_max_val(myArray));
            //thread.Start();

            //Thread thread = new Thread(() => get_ave_val(myArray));
            //thread.Start();

            Thread thread = new Thread(() => get_subtraction(myArray));
            thread.Start();
        }
    }
}
